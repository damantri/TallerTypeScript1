import { series } from './data.js';

console.log("Loading series...");

function generateTableRow(serie) {
  return `<tr>
            <td>${serie.id}</td>
            <td>${serie.name}</td>
            <td>${serie.channel}</td>
            <td>${serie.seasons}</td>
          </tr>`;
}

function displaySeries() {
  const tableBody = document.querySelector('#series-table');
  
  const { tableRows, totalSeasons } = series.reduce(
    (acc, serie) => {
      acc.tableRows += generateTableRow(serie);
      acc.totalSeasons += serie.seasons;
      return acc;
    },
    { tableRows: '', totalSeasons: 0 }
  );


  tableBody.innerHTML = tableRows;

  const averageSeasons = (totalSeasons / series.length).toFixed(1);
  const avgRow = `<tr><td colspan="3">Average Seasons</td><td>${averageSeasons}</td></tr>`;
  tableBody.insertAdjacentHTML('beforeend', avgRow);
}

displaySeries();
